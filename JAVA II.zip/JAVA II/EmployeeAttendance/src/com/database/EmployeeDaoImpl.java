package com.database;

import java.awt.print.Book;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class EmployeeDaoImpl implements EmployeeDao
{

	Connection con=null;

	@Override
	public void search(Employee employee) {
		try {
			con=DBConnection.getConnection();
			String query="Select atd from attendance where id=?";
			PreparedStatement pst=con.prepareStatement(query);
			pst.setInt(1, employee.getId());
			ResultSet rec=pst.executeQuery(query);
			
			ArrayList<Integer> blist=new ArrayList<>();
			while(rec.next())
			{
				int name1=rec.getInt("atd");
				blist.add(name1);
			}
			for(Integer name1:blist)
			{
				System.out.println(name1);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	

}
