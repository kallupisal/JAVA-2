package com.database;

public class Employee 
{
	private int id;
	private String month;
	private int attendance;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(int id, String month, int attendance) {
		super();
		this.id = id;
		this.month = month;
		this.attendance = attendance;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public int getAttendance() {
		return attendance;
	}
	public void setAttendance(int attendance) {
		this.attendance = attendance;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", month=" + month + ", attendance=" + attendance + "]";
	}
	
	
}
