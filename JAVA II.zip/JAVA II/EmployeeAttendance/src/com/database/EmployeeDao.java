package com.database;

public interface EmployeeDao 
{
	public void search(Employee employee);
}
