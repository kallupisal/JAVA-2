package com.user.app;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class UserDaoImpl implements UserDao{

	Connection con=null;
	@Override
	public void insertRecord(User user) 
	{

		String query="insert into user values(default,?,?,?,now())";
			try {
				con=DBConnection.getConnection();
				PreparedStatement pst=con.prepareStatement(query);
				pst.setString(1, user.getUname());
				pst.setString(2, user.getPwd());
				pst.setString(3, user.getPno());
				int record=pst.executeUpdate();
				if(record==1)
				{
					System.out.println("Inserted Successfully");
					return;
				}
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}

}
