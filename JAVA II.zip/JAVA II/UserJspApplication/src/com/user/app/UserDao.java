package com.user.app;

public interface UserDao 
{
	public void insertRecord(User user);
}
