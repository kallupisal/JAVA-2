package com.user.app;

public class User 
{
	private String uname;
	private String pwd;
	private String pno;
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	public User(String uname, String pwd, String pno) {
		super();
		this.uname = uname;
		this.pwd = pwd;
		this.pno = pno;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getPno() {
		return pno;
	}
	public void setPno(String pno) {
		this.pno = pno;
	}
	
}
