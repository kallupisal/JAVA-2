package com.datetime.database;

public class InsertQuery 
{
	
}
