package com.database;

public class Employee 
{
	private String name;
	private String dob;
	private String gender;
	private String email;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(String name, String dob, String gender, String email) {
		super();
		this.name = name;
		this.dob = dob;
		this.gender = gender;
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", dob=" + dob + ", gender=" + gender + ", email=" + email + "]";
	}

}
