package com.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

public class EmployeeDaoImpl implements EmployeeDao
{

	Connection con=null;

	public void insertRecord(Employee employee) 
	{
		String query="insert into employee values(default,?,?,?,?)";
		try {
			con=DBConnection.getConnection();
			PreparedStatement pst=con.prepareStatement(query);
			pst.setString(1, employee.getName());
			pst.setString(2, employee.getDob());
			pst.setString(3, employee.getGender());
			pst.setString(4, employee.getEmail());
			int record=pst.executeUpdate();
			if(record==1)
			{
				System.out.println("Inserted Successfully");
				return;
			}
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}


}
