package com.database;

public interface EmployeeDao 
{
	public void insertRecord(Employee employee);
}
