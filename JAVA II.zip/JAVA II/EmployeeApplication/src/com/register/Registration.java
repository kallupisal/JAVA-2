package com.register;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.database.Employee;
import com.database.EmployeeDao;
import com.database.EmployeeDaoImpl;

@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public Registration() {
        super();
        // TODO Auto-generated constructor stub
    }
//	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
//	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		String name=request.getParameter("name");
		String dob=request.getParameter("dob");
		String gender=request.getParameter("gender");
		String email=request.getParameter("Email");
		
		out.println("Name:"+name+"<br>");
		out.println("DOB :"+dob+"<br>");
		out.println("Gender :"+gender+"<br>");
		out.println("Email :"+email+"<br>");
		
		Employee employee=new Employee(name,dob, gender, email);
		EmployeeDao eDao=new EmployeeDaoImpl();
		eDao.insertRecord(employee);
		System.out.println("Inserted Succesfully");
		HttpSession session=request.getSession();
		session.setAttribute("employeeSession", employee);
		response.sendRedirect("details.jsp");
	}

}
