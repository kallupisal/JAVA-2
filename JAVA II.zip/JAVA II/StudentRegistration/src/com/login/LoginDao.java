package com.login;

public interface LoginDao {
	
	public boolean validateLogin(Login login);

}
