package com.database;

import java.util.ArrayList;

public interface StudentInterface
{
	ArrayList<Student> show();
	public void insertRecord(Student student);
	public void updateRecord(String name,String pwd);
	public void deleteRecord(String name);
	

}
